if (selected === correct) {
  feedback.textContent = "Correct!";
  feedback.className = "feedback correct";
  document.getElementById('next-step-btn').disabled = false;
} else {
  feedback.textContent = `Incorrect. La bonne réponse est : "${correct}".`;
  feedback.className = "feedback incorrect";
  document.getElementById('next-step-btn').disabled = false;
}
